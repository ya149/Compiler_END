﻿namespace topec4_1
{
    partial class MyGrammerLexer
    {
    }
}
